﻿using System;
using System.Windows.Forms;
using CeliAPS.T4I.Woodwork4Inventor.ReplacementProvider.Interfaces;

namespace ReplacementProviderExample
{
    public partial class ReplacementForm : Form
    {
        private readonly IReplacementData _replacementData;

        public ReplacementForm(IReplacementData replacementData)
        {
            InitializeComponent();
            _replacementData = replacementData;
            configurationValueLabel.Text = replacementData.ConfigurationName;

            // Read properties from data to UI
            if (replacementData is IMaterialSizeReplacementData materialData)
            {
                var materialWidth = materialData.Width;
                var materialThickness = materialData.Thickness;

                if (Math.Abs(materialThickness) < 0.0000001)
                    materialSizeValueLabel.Text = @"Any";
                else
                {
                    if (Math.Abs(materialWidth) < 0.0000001)
                        materialSizeValueLabel.Text = $@"{materialThickness * 10} mm";
                    else
                        materialSizeValueLabel.Text = $@"{materialWidth * 10} mm x {materialThickness * 10} mm";
                }

                var material = materialData.Material;
                materialGroupBox.Visible = true;
                materialCodeValueLabel.Text = material.Code;
                materialNameValueLabel.Text = material.Name;
                materialTypeValueLabel.Text = material.Type.ToString();
                materialNewCodeTextBox.Text = material.NewCode;
                materialNewNameTextBox.Text = material.NewName;
                materialNewAppearanceTextBox.Text = material.NewAppearance;

                var color = materialData.Color;
                if (color == null)
                    return;

                colorGroupBox.Visible = true;
                colorCodeValueLabel.Text = color.Code;
                colorNameValueLabel.Text = color.Name;
                colorNewCodeTextBox.Text = color.NewCode;
                colorNewNameTextBox.Text = color.NewName;
                colorNewAppearanceTextBox.Text = color.NewAppearance;
            }

            if (replacementData is IHardwareReplacementData hardwareData)
            {
                var hardware = hardwareData.HardwareComponent;
                hardwareGroupBox.Visible = true;
                hardwareCodeValueLabel.Text = hardware.Code;
                hardwareNameValueLabel.Text = hardware.Name;
                hardwareTypeValueLabel.Text = hardware.Type.ToString();
                hardwareNewCodeTextBox.Text = hardware.NewCode;
                hardwareNewNameTextBox.Text = hardware.NewName;
                hardwareNewAppearanceTextBox.Text = hardware.NewAppearance;
            }
        }

        private void materialBrowseAppearanceButton_Click(object sender, EventArgs e)
        {
            materialNewAppearanceTextBox.Text = BrowseImage();
        }

        private void colorBrowseAppearanceButton_Click(object sender, EventArgs e)
        {
            colorNewAppearanceTextBox.Text = BrowseImage();
        }

        private void hardwareBrowseAppearanceButton_Click(object sender, EventArgs e)
        {
            hardwareNewAppearanceTextBox.Text = BrowseImage();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            // Set back all properties from UI to data.
            if (_replacementData is IMaterialSizeReplacementData materialSizeReplacementData)
            {
                var material = materialSizeReplacementData.Material;
                material.NewCode = materialNewCodeTextBox.Text;
                material.NewName = materialNewNameTextBox.Text;
                material.NewAppearance = materialNewAppearanceTextBox.Text;

                var color = materialSizeReplacementData.Color;
                if (color != null)
                {
                    color.NewCode = colorNewCodeTextBox.Text;
                    color.NewName = colorNewNameTextBox.Text;
                    color.NewAppearance = colorNewAppearanceTextBox.Text;
                }
            }

            if (_replacementData is IHardwareReplacementData hardwareData)
            {
                var hardware = hardwareData.HardwareComponent;
                hardware.NewCode = hardwareNewCodeTextBox.Text;
                hardware.NewName = hardwareNewNameTextBox.Text;
                hardware.NewAppearance = hardwareNewAppearanceTextBox.Text;
            }

            Close();
        }

        private static string BrowseImage()
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Multiselect = false;
                openFileDialog.Filter = "Image files (*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.bmp;*.gif)|*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.bmp;*.gif";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                    return openFileDialog.FileName;

                return null;
            }
        }
    }
}
