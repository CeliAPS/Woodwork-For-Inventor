﻿namespace ReplacementProviderExample
{
    partial class ReplacementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.materialGroupBox = new System.Windows.Forms.GroupBox();
            this.materialSizeValueLabel = new System.Windows.Forms.Label();
            this.materialSizeLabel = new System.Windows.Forms.Label();
            this.materialBrowseAppearanceButton = new System.Windows.Forms.Button();
            this.materialNewAppearanceTextBox = new System.Windows.Forms.TextBox();
            this.materialNewCodeTextBox = new System.Windows.Forms.TextBox();
            this.materialNewNameTextBox = new System.Windows.Forms.TextBox();
            this.materialNewAppearanceLabel = new System.Windows.Forms.Label();
            this.materialNewNameLabel = new System.Windows.Forms.Label();
            this.materialNewCodeLabel = new System.Windows.Forms.Label();
            this.materialTypeValueLabel = new System.Windows.Forms.Label();
            this.materialCodeValueLabel = new System.Windows.Forms.Label();
            this.materialNameValueLabel = new System.Windows.Forms.Label();
            this.materialTypeLabel = new System.Windows.Forms.Label();
            this.materialNameLabel = new System.Windows.Forms.Label();
            this.materialCodeLabel = new System.Windows.Forms.Label();
            this.colorGroupBox = new System.Windows.Forms.GroupBox();
            this.colorBrowseAppearanceButton = new System.Windows.Forms.Button();
            this.colorNewCodeTextBox = new System.Windows.Forms.TextBox();
            this.colorNewAppearanceTextBox = new System.Windows.Forms.TextBox();
            this.colorNewNameTextBox = new System.Windows.Forms.TextBox();
            this.colorNewAppearanceLabel = new System.Windows.Forms.Label();
            this.colorNewNameLabel = new System.Windows.Forms.Label();
            this.colorNewCodeLabel = new System.Windows.Forms.Label();
            this.colorCodeValueLabel = new System.Windows.Forms.Label();
            this.colorNameValueLabel = new System.Windows.Forms.Label();
            this.colorNameLabel = new System.Windows.Forms.Label();
            this.colorCodeLabel = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.hardwareGroupBox = new System.Windows.Forms.GroupBox();
            this.hardwareBrowseAppearanceButton = new System.Windows.Forms.Button();
            this.hardwareNewAppearanceTextBox = new System.Windows.Forms.TextBox();
            this.hardwareNewCodeTextBox = new System.Windows.Forms.TextBox();
            this.hardwareNewNameTextBox = new System.Windows.Forms.TextBox();
            this.hardwareNewAppearanceLabel = new System.Windows.Forms.Label();
            this.hardwareNewNameLabel = new System.Windows.Forms.Label();
            this.hardwareNewCodeLabel = new System.Windows.Forms.Label();
            this.hardwareTypeValueLabel = new System.Windows.Forms.Label();
            this.hardwareCodeValueLabel = new System.Windows.Forms.Label();
            this.hardwareNameValueLabel = new System.Windows.Forms.Label();
            this.hardwareTypeLabel = new System.Windows.Forms.Label();
            this.hardwareNameLabel = new System.Windows.Forms.Label();
            this.hardwareCodeLabel = new System.Windows.Forms.Label();
            this.configurationLabel = new System.Windows.Forms.Label();
            this.configurationValueLabel = new System.Windows.Forms.Label();
            this.materialGroupBox.SuspendLayout();
            this.colorGroupBox.SuspendLayout();
            this.hardwareGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // materialGroupBox
            // 
            this.materialGroupBox.Controls.Add(this.materialSizeValueLabel);
            this.materialGroupBox.Controls.Add(this.materialSizeLabel);
            this.materialGroupBox.Controls.Add(this.materialBrowseAppearanceButton);
            this.materialGroupBox.Controls.Add(this.materialNewAppearanceTextBox);
            this.materialGroupBox.Controls.Add(this.materialNewCodeTextBox);
            this.materialGroupBox.Controls.Add(this.materialNewNameTextBox);
            this.materialGroupBox.Controls.Add(this.materialNewAppearanceLabel);
            this.materialGroupBox.Controls.Add(this.materialNewNameLabel);
            this.materialGroupBox.Controls.Add(this.materialNewCodeLabel);
            this.materialGroupBox.Controls.Add(this.materialTypeValueLabel);
            this.materialGroupBox.Controls.Add(this.materialCodeValueLabel);
            this.materialGroupBox.Controls.Add(this.materialNameValueLabel);
            this.materialGroupBox.Controls.Add(this.materialTypeLabel);
            this.materialGroupBox.Controls.Add(this.materialNameLabel);
            this.materialGroupBox.Controls.Add(this.materialCodeLabel);
            this.materialGroupBox.Location = new System.Drawing.Point(12, 12);
            this.materialGroupBox.Name = "materialGroupBox";
            this.materialGroupBox.Padding = new System.Windows.Forms.Padding(5);
            this.materialGroupBox.Size = new System.Drawing.Size(330, 174);
            this.materialGroupBox.TabIndex = 0;
            this.materialGroupBox.TabStop = false;
            this.materialGroupBox.Text = "Material";
            this.materialGroupBox.Visible = false;
            // 
            // materialSizeValueLabel
            // 
            this.materialSizeValueLabel.AutoSize = true;
            this.materialSizeValueLabel.Location = new System.Drawing.Point(104, 84);
            this.materialSizeValueLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialSizeValueLabel.Name = "materialSizeValueLabel";
            this.materialSizeValueLabel.Size = new System.Drawing.Size(25, 13);
            this.materialSizeValueLabel.TabIndex = 18;
            this.materialSizeValueLabel.Text = "size";
            // 
            // materialSizeLabel
            // 
            this.materialSizeLabel.AutoSize = true;
            this.materialSizeLabel.Location = new System.Drawing.Point(8, 84);
            this.materialSizeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialSizeLabel.Name = "materialSizeLabel";
            this.materialSizeLabel.Size = new System.Drawing.Size(30, 13);
            this.materialSizeLabel.TabIndex = 17;
            this.materialSizeLabel.Text = "Size:";
            // 
            // materialBrowseAppearanceButton
            // 
            this.materialBrowseAppearanceButton.Location = new System.Drawing.Point(291, 143);
            this.materialBrowseAppearanceButton.Margin = new System.Windows.Forms.Padding(1);
            this.materialBrowseAppearanceButton.Name = "materialBrowseAppearanceButton";
            this.materialBrowseAppearanceButton.Size = new System.Drawing.Size(30, 22);
            this.materialBrowseAppearanceButton.TabIndex = 16;
            this.materialBrowseAppearanceButton.Text = "...";
            this.materialBrowseAppearanceButton.UseVisualStyleBackColor = true;
            this.materialBrowseAppearanceButton.Click += new System.EventHandler(this.materialBrowseAppearanceButton_Click);
            // 
            // materialNewAppearanceTextBox
            // 
            this.materialNewAppearanceTextBox.Location = new System.Drawing.Point(107, 144);
            this.materialNewAppearanceTextBox.Name = "materialNewAppearanceTextBox";
            this.materialNewAppearanceTextBox.ReadOnly = true;
            this.materialNewAppearanceTextBox.Size = new System.Drawing.Size(184, 20);
            this.materialNewAppearanceTextBox.TabIndex = 15;
            // 
            // materialNewCodeTextBox
            // 
            this.materialNewCodeTextBox.Location = new System.Drawing.Point(107, 102);
            this.materialNewCodeTextBox.Name = "materialNewCodeTextBox";
            this.materialNewCodeTextBox.Size = new System.Drawing.Size(213, 20);
            this.materialNewCodeTextBox.TabIndex = 14;
            // 
            // materialNewNameTextBox
            // 
            this.materialNewNameTextBox.Location = new System.Drawing.Point(107, 123);
            this.materialNewNameTextBox.Name = "materialNewNameTextBox";
            this.materialNewNameTextBox.Size = new System.Drawing.Size(213, 20);
            this.materialNewNameTextBox.TabIndex = 12;
            // 
            // materialNewAppearanceLabel
            // 
            this.materialNewAppearanceLabel.AutoSize = true;
            this.materialNewAppearanceLabel.Location = new System.Drawing.Point(8, 147);
            this.materialNewAppearanceLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialNewAppearanceLabel.Name = "materialNewAppearanceLabel";
            this.materialNewAppearanceLabel.Size = new System.Drawing.Size(92, 13);
            this.materialNewAppearanceLabel.TabIndex = 8;
            this.materialNewAppearanceLabel.Text = "New appearance:";
            // 
            // materialNewNameLabel
            // 
            this.materialNewNameLabel.AutoSize = true;
            this.materialNewNameLabel.Location = new System.Drawing.Point(8, 126);
            this.materialNewNameLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialNewNameLabel.Name = "materialNewNameLabel";
            this.materialNewNameLabel.Size = new System.Drawing.Size(61, 13);
            this.materialNewNameLabel.TabIndex = 7;
            this.materialNewNameLabel.Text = "New name:";
            // 
            // materialNewCodeLabel
            // 
            this.materialNewCodeLabel.AutoSize = true;
            this.materialNewCodeLabel.Location = new System.Drawing.Point(8, 105);
            this.materialNewCodeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialNewCodeLabel.Name = "materialNewCodeLabel";
            this.materialNewCodeLabel.Size = new System.Drawing.Size(59, 13);
            this.materialNewCodeLabel.TabIndex = 6;
            this.materialNewCodeLabel.Text = "New code:";
            // 
            // materialTypeValueLabel
            // 
            this.materialTypeValueLabel.AutoSize = true;
            this.materialTypeValueLabel.Location = new System.Drawing.Point(104, 63);
            this.materialTypeValueLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialTypeValueLabel.Name = "materialTypeValueLabel";
            this.materialTypeValueLabel.Size = new System.Drawing.Size(27, 13);
            this.materialTypeValueLabel.TabIndex = 5;
            this.materialTypeValueLabel.Text = "type";
            // 
            // materialCodeValueLabel
            // 
            this.materialCodeValueLabel.AutoSize = true;
            this.materialCodeValueLabel.Location = new System.Drawing.Point(104, 21);
            this.materialCodeValueLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialCodeValueLabel.Name = "materialCodeValueLabel";
            this.materialCodeValueLabel.Size = new System.Drawing.Size(31, 13);
            this.materialCodeValueLabel.TabIndex = 4;
            this.materialCodeValueLabel.Text = "code";
            // 
            // materialNameValueLabel
            // 
            this.materialNameValueLabel.AutoSize = true;
            this.materialNameValueLabel.Location = new System.Drawing.Point(104, 42);
            this.materialNameValueLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialNameValueLabel.Name = "materialNameValueLabel";
            this.materialNameValueLabel.Size = new System.Drawing.Size(33, 13);
            this.materialNameValueLabel.TabIndex = 3;
            this.materialNameValueLabel.Text = "name";
            // 
            // materialTypeLabel
            // 
            this.materialTypeLabel.AutoSize = true;
            this.materialTypeLabel.Location = new System.Drawing.Point(8, 63);
            this.materialTypeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialTypeLabel.Name = "materialTypeLabel";
            this.materialTypeLabel.Size = new System.Drawing.Size(34, 13);
            this.materialTypeLabel.TabIndex = 2;
            this.materialTypeLabel.Text = "Type:";
            // 
            // materialNameLabel
            // 
            this.materialNameLabel.AutoSize = true;
            this.materialNameLabel.Location = new System.Drawing.Point(8, 42);
            this.materialNameLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialNameLabel.Name = "materialNameLabel";
            this.materialNameLabel.Size = new System.Drawing.Size(38, 13);
            this.materialNameLabel.TabIndex = 1;
            this.materialNameLabel.Text = "Name:";
            // 
            // materialCodeLabel
            // 
            this.materialCodeLabel.AutoSize = true;
            this.materialCodeLabel.Location = new System.Drawing.Point(8, 21);
            this.materialCodeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.materialCodeLabel.Name = "materialCodeLabel";
            this.materialCodeLabel.Size = new System.Drawing.Size(35, 13);
            this.materialCodeLabel.TabIndex = 0;
            this.materialCodeLabel.Text = "Code:";
            // 
            // colorGroupBox
            // 
            this.colorGroupBox.Controls.Add(this.colorBrowseAppearanceButton);
            this.colorGroupBox.Controls.Add(this.colorNewCodeTextBox);
            this.colorGroupBox.Controls.Add(this.colorNewAppearanceTextBox);
            this.colorGroupBox.Controls.Add(this.colorNewNameTextBox);
            this.colorGroupBox.Controls.Add(this.colorNewAppearanceLabel);
            this.colorGroupBox.Controls.Add(this.colorNewNameLabel);
            this.colorGroupBox.Controls.Add(this.colorNewCodeLabel);
            this.colorGroupBox.Controls.Add(this.colorCodeValueLabel);
            this.colorGroupBox.Controls.Add(this.colorNameValueLabel);
            this.colorGroupBox.Controls.Add(this.colorNameLabel);
            this.colorGroupBox.Controls.Add(this.colorCodeLabel);
            this.colorGroupBox.Location = new System.Drawing.Point(12, 192);
            this.colorGroupBox.Name = "colorGroupBox";
            this.colorGroupBox.Padding = new System.Windows.Forms.Padding(5);
            this.colorGroupBox.Size = new System.Drawing.Size(330, 136);
            this.colorGroupBox.TabIndex = 1;
            this.colorGroupBox.TabStop = false;
            this.colorGroupBox.Text = "Color";
            this.colorGroupBox.Visible = false;
            // 
            // colorBrowseAppearanceButton
            // 
            this.colorBrowseAppearanceButton.Location = new System.Drawing.Point(291, 101);
            this.colorBrowseAppearanceButton.Margin = new System.Windows.Forms.Padding(1);
            this.colorBrowseAppearanceButton.Name = "colorBrowseAppearanceButton";
            this.colorBrowseAppearanceButton.Size = new System.Drawing.Size(30, 22);
            this.colorBrowseAppearanceButton.TabIndex = 18;
            this.colorBrowseAppearanceButton.Text = "...";
            this.colorBrowseAppearanceButton.UseVisualStyleBackColor = true;
            this.colorBrowseAppearanceButton.Click += new System.EventHandler(this.colorBrowseAppearanceButton_Click);
            // 
            // colorNewCodeTextBox
            // 
            this.colorNewCodeTextBox.Location = new System.Drawing.Point(107, 60);
            this.colorNewCodeTextBox.Name = "colorNewCodeTextBox";
            this.colorNewCodeTextBox.Size = new System.Drawing.Size(213, 20);
            this.colorNewCodeTextBox.TabIndex = 14;
            // 
            // colorNewAppearanceTextBox
            // 
            this.colorNewAppearanceTextBox.Location = new System.Drawing.Point(107, 102);
            this.colorNewAppearanceTextBox.Name = "colorNewAppearanceTextBox";
            this.colorNewAppearanceTextBox.ReadOnly = true;
            this.colorNewAppearanceTextBox.Size = new System.Drawing.Size(184, 20);
            this.colorNewAppearanceTextBox.TabIndex = 17;
            // 
            // colorNewNameTextBox
            // 
            this.colorNewNameTextBox.Location = new System.Drawing.Point(107, 81);
            this.colorNewNameTextBox.Name = "colorNewNameTextBox";
            this.colorNewNameTextBox.Size = new System.Drawing.Size(213, 20);
            this.colorNewNameTextBox.TabIndex = 12;
            // 
            // colorNewAppearanceLabel
            // 
            this.colorNewAppearanceLabel.AutoSize = true;
            this.colorNewAppearanceLabel.Location = new System.Drawing.Point(8, 105);
            this.colorNewAppearanceLabel.Margin = new System.Windows.Forms.Padding(4);
            this.colorNewAppearanceLabel.Name = "colorNewAppearanceLabel";
            this.colorNewAppearanceLabel.Size = new System.Drawing.Size(92, 13);
            this.colorNewAppearanceLabel.TabIndex = 8;
            this.colorNewAppearanceLabel.Text = "New appearance:";
            // 
            // colorNewNameLabel
            // 
            this.colorNewNameLabel.AutoSize = true;
            this.colorNewNameLabel.Location = new System.Drawing.Point(8, 84);
            this.colorNewNameLabel.Margin = new System.Windows.Forms.Padding(4);
            this.colorNewNameLabel.Name = "colorNewNameLabel";
            this.colorNewNameLabel.Size = new System.Drawing.Size(61, 13);
            this.colorNewNameLabel.TabIndex = 7;
            this.colorNewNameLabel.Text = "New name:";
            // 
            // colorNewCodeLabel
            // 
            this.colorNewCodeLabel.AutoSize = true;
            this.colorNewCodeLabel.Location = new System.Drawing.Point(8, 63);
            this.colorNewCodeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.colorNewCodeLabel.Name = "colorNewCodeLabel";
            this.colorNewCodeLabel.Size = new System.Drawing.Size(59, 13);
            this.colorNewCodeLabel.TabIndex = 6;
            this.colorNewCodeLabel.Text = "New code:";
            // 
            // colorCodeValueLabel
            // 
            this.colorCodeValueLabel.AutoSize = true;
            this.colorCodeValueLabel.Location = new System.Drawing.Point(104, 21);
            this.colorCodeValueLabel.Margin = new System.Windows.Forms.Padding(4);
            this.colorCodeValueLabel.Name = "colorCodeValueLabel";
            this.colorCodeValueLabel.Size = new System.Drawing.Size(31, 13);
            this.colorCodeValueLabel.TabIndex = 4;
            this.colorCodeValueLabel.Text = "code";
            // 
            // colorNameValueLabel
            // 
            this.colorNameValueLabel.AutoSize = true;
            this.colorNameValueLabel.Location = new System.Drawing.Point(104, 42);
            this.colorNameValueLabel.Margin = new System.Windows.Forms.Padding(4);
            this.colorNameValueLabel.Name = "colorNameValueLabel";
            this.colorNameValueLabel.Size = new System.Drawing.Size(33, 13);
            this.colorNameValueLabel.TabIndex = 3;
            this.colorNameValueLabel.Text = "name";
            // 
            // colorNameLabel
            // 
            this.colorNameLabel.AutoSize = true;
            this.colorNameLabel.Location = new System.Drawing.Point(8, 42);
            this.colorNameLabel.Margin = new System.Windows.Forms.Padding(4);
            this.colorNameLabel.Name = "colorNameLabel";
            this.colorNameLabel.Size = new System.Drawing.Size(38, 13);
            this.colorNameLabel.TabIndex = 1;
            this.colorNameLabel.Text = "Name:";
            // 
            // colorCodeLabel
            // 
            this.colorCodeLabel.AutoSize = true;
            this.colorCodeLabel.Location = new System.Drawing.Point(8, 21);
            this.colorCodeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.colorCodeLabel.Name = "colorCodeLabel";
            this.colorCodeLabel.Size = new System.Drawing.Size(35, 13);
            this.colorCodeLabel.TabIndex = 0;
            this.colorCodeLabel.Text = "Code:";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(267, 334);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // hardwareGroupBox
            // 
            this.hardwareGroupBox.Controls.Add(this.hardwareBrowseAppearanceButton);
            this.hardwareGroupBox.Controls.Add(this.hardwareNewAppearanceTextBox);
            this.hardwareGroupBox.Controls.Add(this.hardwareNewCodeTextBox);
            this.hardwareGroupBox.Controls.Add(this.hardwareNewNameTextBox);
            this.hardwareGroupBox.Controls.Add(this.hardwareNewAppearanceLabel);
            this.hardwareGroupBox.Controls.Add(this.hardwareNewNameLabel);
            this.hardwareGroupBox.Controls.Add(this.hardwareNewCodeLabel);
            this.hardwareGroupBox.Controls.Add(this.hardwareTypeValueLabel);
            this.hardwareGroupBox.Controls.Add(this.hardwareCodeValueLabel);
            this.hardwareGroupBox.Controls.Add(this.hardwareNameValueLabel);
            this.hardwareGroupBox.Controls.Add(this.hardwareTypeLabel);
            this.hardwareGroupBox.Controls.Add(this.hardwareNameLabel);
            this.hardwareGroupBox.Controls.Add(this.hardwareCodeLabel);
            this.hardwareGroupBox.Location = new System.Drawing.Point(12, 12);
            this.hardwareGroupBox.Name = "hardwareGroupBox";
            this.hardwareGroupBox.Padding = new System.Windows.Forms.Padding(5);
            this.hardwareGroupBox.Size = new System.Drawing.Size(330, 174);
            this.hardwareGroupBox.TabIndex = 3;
            this.hardwareGroupBox.TabStop = false;
            this.hardwareGroupBox.Text = "Hardware";
            this.hardwareGroupBox.Visible = false;
            // 
            // hardwareBrowseAppearanceButton
            // 
            this.hardwareBrowseAppearanceButton.Location = new System.Drawing.Point(291, 122);
            this.hardwareBrowseAppearanceButton.Margin = new System.Windows.Forms.Padding(1);
            this.hardwareBrowseAppearanceButton.Name = "hardwareBrowseAppearanceButton";
            this.hardwareBrowseAppearanceButton.Size = new System.Drawing.Size(30, 22);
            this.hardwareBrowseAppearanceButton.TabIndex = 16;
            this.hardwareBrowseAppearanceButton.Text = "...";
            this.hardwareBrowseAppearanceButton.UseVisualStyleBackColor = true;
            this.hardwareBrowseAppearanceButton.Click += new System.EventHandler(this.hardwareBrowseAppearanceButton_Click);
            // 
            // hardwareNewAppearanceTextBox
            // 
            this.hardwareNewAppearanceTextBox.Location = new System.Drawing.Point(107, 123);
            this.hardwareNewAppearanceTextBox.Name = "hardwareNewAppearanceTextBox";
            this.hardwareNewAppearanceTextBox.ReadOnly = true;
            this.hardwareNewAppearanceTextBox.Size = new System.Drawing.Size(184, 20);
            this.hardwareNewAppearanceTextBox.TabIndex = 15;
            // 
            // hardwareNewCodeTextBox
            // 
            this.hardwareNewCodeTextBox.Location = new System.Drawing.Point(107, 81);
            this.hardwareNewCodeTextBox.Name = "hardwareNewCodeTextBox";
            this.hardwareNewCodeTextBox.Size = new System.Drawing.Size(213, 20);
            this.hardwareNewCodeTextBox.TabIndex = 14;
            // 
            // hardwareNewNameTextBox
            // 
            this.hardwareNewNameTextBox.Location = new System.Drawing.Point(107, 102);
            this.hardwareNewNameTextBox.Name = "hardwareNewNameTextBox";
            this.hardwareNewNameTextBox.Size = new System.Drawing.Size(213, 20);
            this.hardwareNewNameTextBox.TabIndex = 12;
            // 
            // hardwareNewAppearanceLabel
            // 
            this.hardwareNewAppearanceLabel.AutoSize = true;
            this.hardwareNewAppearanceLabel.Location = new System.Drawing.Point(8, 126);
            this.hardwareNewAppearanceLabel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareNewAppearanceLabel.Name = "hardwareNewAppearanceLabel";
            this.hardwareNewAppearanceLabel.Size = new System.Drawing.Size(92, 13);
            this.hardwareNewAppearanceLabel.TabIndex = 8;
            this.hardwareNewAppearanceLabel.Text = "New appearance:";
            // 
            // hardwareNewNameLabel
            // 
            this.hardwareNewNameLabel.AutoSize = true;
            this.hardwareNewNameLabel.Location = new System.Drawing.Point(8, 105);
            this.hardwareNewNameLabel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareNewNameLabel.Name = "hardwareNewNameLabel";
            this.hardwareNewNameLabel.Size = new System.Drawing.Size(61, 13);
            this.hardwareNewNameLabel.TabIndex = 7;
            this.hardwareNewNameLabel.Text = "New name:";
            // 
            // hardwareNewCodeLabel
            // 
            this.hardwareNewCodeLabel.AutoSize = true;
            this.hardwareNewCodeLabel.Location = new System.Drawing.Point(8, 84);
            this.hardwareNewCodeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareNewCodeLabel.Name = "hardwareNewCodeLabel";
            this.hardwareNewCodeLabel.Size = new System.Drawing.Size(59, 13);
            this.hardwareNewCodeLabel.TabIndex = 6;
            this.hardwareNewCodeLabel.Text = "New code:";
            // 
            // hardwareTypeValueLabel
            // 
            this.hardwareTypeValueLabel.AutoSize = true;
            this.hardwareTypeValueLabel.Location = new System.Drawing.Point(104, 63);
            this.hardwareTypeValueLabel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareTypeValueLabel.Name = "hardwareTypeValueLabel";
            this.hardwareTypeValueLabel.Size = new System.Drawing.Size(27, 13);
            this.hardwareTypeValueLabel.TabIndex = 5;
            this.hardwareTypeValueLabel.Text = "type";
            // 
            // hardwareCodeValueLabel
            // 
            this.hardwareCodeValueLabel.AutoSize = true;
            this.hardwareCodeValueLabel.Location = new System.Drawing.Point(104, 21);
            this.hardwareCodeValueLabel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareCodeValueLabel.Name = "hardwareCodeValueLabel";
            this.hardwareCodeValueLabel.Size = new System.Drawing.Size(31, 13);
            this.hardwareCodeValueLabel.TabIndex = 4;
            this.hardwareCodeValueLabel.Text = "code";
            // 
            // hardwareNameValueLabel
            // 
            this.hardwareNameValueLabel.AutoSize = true;
            this.hardwareNameValueLabel.Location = new System.Drawing.Point(104, 42);
            this.hardwareNameValueLabel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareNameValueLabel.Name = "hardwareNameValueLabel";
            this.hardwareNameValueLabel.Size = new System.Drawing.Size(33, 13);
            this.hardwareNameValueLabel.TabIndex = 3;
            this.hardwareNameValueLabel.Text = "name";
            // 
            // hardwareTypeLabel
            // 
            this.hardwareTypeLabel.AutoSize = true;
            this.hardwareTypeLabel.Location = new System.Drawing.Point(8, 63);
            this.hardwareTypeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareTypeLabel.Name = "hardwareTypeLabel";
            this.hardwareTypeLabel.Size = new System.Drawing.Size(34, 13);
            this.hardwareTypeLabel.TabIndex = 2;
            this.hardwareTypeLabel.Text = "Type:";
            // 
            // hardwareNameLabel
            // 
            this.hardwareNameLabel.AutoSize = true;
            this.hardwareNameLabel.Location = new System.Drawing.Point(8, 42);
            this.hardwareNameLabel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareNameLabel.Name = "hardwareNameLabel";
            this.hardwareNameLabel.Size = new System.Drawing.Size(38, 13);
            this.hardwareNameLabel.TabIndex = 1;
            this.hardwareNameLabel.Text = "Name:";
            // 
            // hardwareCodeLabel
            // 
            this.hardwareCodeLabel.AutoSize = true;
            this.hardwareCodeLabel.Location = new System.Drawing.Point(8, 21);
            this.hardwareCodeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareCodeLabel.Name = "hardwareCodeLabel";
            this.hardwareCodeLabel.Size = new System.Drawing.Size(35, 13);
            this.hardwareCodeLabel.TabIndex = 0;
            this.hardwareCodeLabel.Text = "Code:";
            // 
            // configurationLabel
            // 
            this.configurationLabel.AutoSize = true;
            this.configurationLabel.Location = new System.Drawing.Point(20, 339);
            this.configurationLabel.Name = "configurationLabel";
            this.configurationLabel.Size = new System.Drawing.Size(72, 13);
            this.configurationLabel.TabIndex = 3;
            this.configurationLabel.Text = "Configuration:";
            // 
            // configurationValueLabel
            // 
            this.configurationValueLabel.AutoSize = true;
            this.configurationValueLabel.Location = new System.Drawing.Point(98, 339);
            this.configurationValueLabel.Name = "configurationValueLabel";
            this.configurationValueLabel.Size = new System.Drawing.Size(68, 13);
            this.configurationValueLabel.TabIndex = 4;
            this.configurationValueLabel.Text = "configuration";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 366);
            this.Controls.Add(this.configurationValueLabel);
            this.Controls.Add(this.configurationLabel);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.colorGroupBox);
            this.Controls.Add(this.materialGroupBox);
            this.Controls.Add(this.hardwareGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.Text = "Replacement example";
            this.materialGroupBox.ResumeLayout(false);
            this.materialGroupBox.PerformLayout();
            this.colorGroupBox.ResumeLayout(false);
            this.colorGroupBox.PerformLayout();
            this.hardwareGroupBox.ResumeLayout(false);
            this.hardwareGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox materialGroupBox;
        private System.Windows.Forms.Label materialNameLabel;
        private System.Windows.Forms.Label materialCodeLabel;
        private System.Windows.Forms.Label materialNewAppearanceLabel;
        private System.Windows.Forms.Label materialNewNameLabel;
        private System.Windows.Forms.Label materialNewCodeLabel;
        private System.Windows.Forms.Label materialTypeValueLabel;
        private System.Windows.Forms.Label materialCodeValueLabel;
        private System.Windows.Forms.Label materialNameValueLabel;
        private System.Windows.Forms.Label materialTypeLabel;
        private System.Windows.Forms.TextBox materialNewCodeTextBox;
        private System.Windows.Forms.TextBox materialNewNameTextBox;
        private System.Windows.Forms.GroupBox colorGroupBox;
        private System.Windows.Forms.TextBox colorNewCodeTextBox;
        private System.Windows.Forms.TextBox colorNewNameTextBox;
        private System.Windows.Forms.Label colorNewAppearanceLabel;
        private System.Windows.Forms.Label colorNewNameLabel;
        private System.Windows.Forms.Label colorNewCodeLabel;
        private System.Windows.Forms.Label colorCodeValueLabel;
        private System.Windows.Forms.Label colorNameValueLabel;
        private System.Windows.Forms.Label colorNameLabel;
        private System.Windows.Forms.Label colorCodeLabel;
        private System.Windows.Forms.Button materialBrowseAppearanceButton;
        private System.Windows.Forms.TextBox materialNewAppearanceTextBox;
        private System.Windows.Forms.Button colorBrowseAppearanceButton;
        private System.Windows.Forms.TextBox colorNewAppearanceTextBox;
        private System.Windows.Forms.Label materialSizeValueLabel;
        private System.Windows.Forms.Label materialSizeLabel;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.GroupBox hardwareGroupBox;
        private System.Windows.Forms.Button hardwareBrowseAppearanceButton;
        private System.Windows.Forms.TextBox hardwareNewAppearanceTextBox;
        private System.Windows.Forms.TextBox hardwareNewCodeTextBox;
        private System.Windows.Forms.TextBox hardwareNewNameTextBox;
        private System.Windows.Forms.Label hardwareNewAppearanceLabel;
        private System.Windows.Forms.Label hardwareNewNameLabel;
        private System.Windows.Forms.Label hardwareNewCodeLabel;
        private System.Windows.Forms.Label hardwareTypeValueLabel;
        private System.Windows.Forms.Label hardwareCodeValueLabel;
        private System.Windows.Forms.Label hardwareNameValueLabel;
        private System.Windows.Forms.Label hardwareTypeLabel;
        private System.Windows.Forms.Label hardwareNameLabel;
        private System.Windows.Forms.Label hardwareCodeLabel;
        private System.Windows.Forms.Label configurationLabel;
        private System.Windows.Forms.Label configurationValueLabel;
    }
}