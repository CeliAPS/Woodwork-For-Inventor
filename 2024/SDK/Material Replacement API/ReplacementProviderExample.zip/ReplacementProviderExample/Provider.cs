﻿using CeliAPS.T4I.Woodwork4Inventor.ReplacementProvider.Interfaces;

namespace ReplacementProviderExample
{
    /// <summary>
    /// Example Woodwork for Inventor replacement provider class.
    /// </summary>
    public class Provider : IReplacementProvider // Woodwork4Inventor.ReplacementProvider.dll must be referenced. Can be found in C:\Program Files\Woodwork for Inventor (Inventor version) (Woodwork version)
    {
        /// <summary>
        /// This method is called by Woodwork for Inventor when replacement for hardware component, material or color is requested.
        /// </summary>
        /// <param name="replacementData">Provides access to replace configuration and replaceable object.</param>
        public void Replace(IReplacementData replacementData)
        {
            // Replacement data can be of 5 types. By finding out the type we can determine what item replacement is requested.

            // IMaterialSizeReplacementData - material, color and size combination
            // IHardwareReplacementData - hardware item
            new ReplacementForm(replacementData).Show();

            // Legacy data that works with old replacement dialog.
            // IMaterialGroupReplacementData - material and color combination
            // IMaterialReplacementData - generic material
            // IColorReplacementData - generic color
        }
    }
}